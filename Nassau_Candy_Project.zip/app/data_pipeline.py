"""
Nassau Candy Distributor - Data Pipeline
Cleans raw order data, joins factory/product lookup tables, engineers
route-level features, and computes KPIs used by the Streamlit dashboard.

This module is imported by app.py and can also be run standalone:
    python data_pipeline.py
to regenerate the processed CSVs in /data.
"""

import os
import numpy as np
import pandas as pd

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")

RAW_ORDERS_PATH = os.path.join(DATA_DIR, "Nassau_Candy_Distributor.csv")
FACTORY_COORDS_PATH = os.path.join(DATA_DIR, "factory_coordinates.csv")
PRODUCT_FACTORY_PATH = os.path.join(DATA_DIR, "product_factory_map.csv")

# ---------------------------------------------------------------------------
# NOTE ON LEAD TIME:
# The raw "Ship Date" field is not realistically related to "Order Date" in
# this dataset (orders fall in 2024-2025, ship dates fall in 2026-2030,
# producing multi-year "lead times"). This is documented in the project
# guide as a data quality issue. Rather than hide it, we compute a
# RELATIVE lead time: each order's raw day-gap is kept, but we present it
# to users as an ORDINAL efficiency signal (lower = relatively faster)
# rather than a literal number of calendar days. The raw value is still
# used for ranking/benchmarking, which is valid even though the absolute
# magnitude is not physically meaningful.
# ---------------------------------------------------------------------------


def load_and_clean_orders(path: str = RAW_ORDERS_PATH) -> pd.DataFrame:
    df = pd.read_csv(path)

    # Parse dates correctly (source format is DD-MM-YYYY)
    df["Order Date"] = pd.to_datetime(df["Order Date"], format="%d-%m-%Y", errors="coerce")
    df["Ship Date"] = pd.to_datetime(df["Ship Date"], format="%d-%m-%Y", errors="coerce")

    # Drop rows where dates failed to parse
    before = len(df)
    df = df.dropna(subset=["Order Date", "Ship Date"])
    dropped = before - len(df)

    # Standardize text fields
    for col in ["City", "State/Province", "Region", "Country/Region", "Division", "Ship Mode"]:
        df[col] = df[col].astype(str).str.strip()

    # Raw lead time in days (see module docstring note above)
    df["Lead Time (raw days)"] = (df["Ship Date"] - df["Order Date"]).dt.days

    # Remove structurally invalid rows (negative lead time = shipped before ordered)
    invalid = df["Lead Time (raw days)"] < 0
    df = df[~invalid]

    df.attrs["rows_dropped_bad_dates"] = dropped
    df.attrs["rows_dropped_negative_leadtime"] = int(invalid.sum())

    # Time features
    df["Order Month"] = df["Order Date"].dt.to_period("M").astype(str)
    df["Order Quarter"] = df["Order Date"].dt.to_period("Q").astype(str)

    # Profit margin
    df["Profit Margin"] = np.where(df["Sales"] > 0, df["Gross Profit"] / df["Sales"], np.nan)

    return df.reset_index(drop=True)


def attach_factory(df: pd.DataFrame) -> pd.DataFrame:
    """Join each order to the factory that produced it, via Product Name."""
    prod_map = pd.read_csv(PRODUCT_FACTORY_PATH)[["Product Name", "Factory"]]
    df = df.merge(prod_map, on="Product Name", how="left")
    return df


def attach_factory_coords(df: pd.DataFrame) -> pd.DataFrame:
    coords = pd.read_csv(FACTORY_COORDS_PATH)
    df = df.merge(coords, on="Factory", how="left")
    return df


def build_route_columns(df: pd.DataFrame) -> pd.DataFrame:
    df["Route (State)"] = df["Factory"] + " -> " + df["State/Province"]
    df["Route (Region)"] = df["Factory"] + " -> " + df["Region"]
    return df


def full_pipeline() -> pd.DataFrame:
    df = load_and_clean_orders()
    df = attach_factory(df)
    df = attach_factory_coords(df)
    df = build_route_columns(df)
    return df


# ---------------------------------------------------------------------------
# Aggregation / KPI functions
# ---------------------------------------------------------------------------

def route_summary(df: pd.DataFrame, level: str = "State") -> pd.DataFrame:
    """
    level: 'State' or 'Region'
    Returns one row per Factory->State (or Factory->Region) route with
    volume, avg lead time, lead time std dev, sales, and an efficiency score.
    """
    route_col = f"Route ({level})"
    geo_col = "State/Province" if level == "State" else "Region"

    grouped = df.groupby(["Factory", geo_col, route_col]).agg(
        Shipments=("Order ID", "count"),
        Avg_Lead_Time=("Lead Time (raw days)", "mean"),
        Lead_Time_StdDev=("Lead Time (raw days)", "std"),
        Total_Sales=("Sales", "sum"),
        Total_Units=("Units", "sum"),
        Total_Gross_Profit=("Gross Profit", "sum"),
    ).reset_index()

    grouped["Lead_Time_StdDev"] = grouped["Lead_Time_StdDev"].fillna(0)

    # Efficiency score: min-max normalized, inverted so 100 = fastest route
    min_lt, max_lt = grouped["Avg_Lead_Time"].min(), grouped["Avg_Lead_Time"].max()
    if max_lt > min_lt:
        grouped["Efficiency_Score"] = 100 * (1 - (grouped["Avg_Lead_Time"] - min_lt) / (max_lt - min_lt))
    else:
        grouped["Efficiency_Score"] = 100.0

    return grouped.sort_values("Avg_Lead_Time")


def delay_frequency(df: pd.DataFrame, threshold_days: float, group_col: str = "State/Province") -> pd.DataFrame:
    """% of shipments per group exceeding the lead-time threshold."""
    tmp = df.copy()
    tmp["Delayed"] = tmp["Lead Time (raw days)"] > threshold_days
    out = tmp.groupby(group_col).agg(
        Shipments=("Order ID", "count"),
        Delayed_Shipments=("Delayed", "sum"),
        Avg_Lead_Time=("Lead Time (raw days)", "mean"),
    ).reset_index()
    out["Delay_Frequency_%"] = 100 * out["Delayed_Shipments"] / out["Shipments"]
    return out.sort_values("Delay_Frequency_%", ascending=False)


def bottleneck_states(df: pd.DataFrame) -> pd.DataFrame:
    """States with both above-median volume AND above-median avg lead time."""
    by_state = df.groupby("State/Province").agg(
        Shipments=("Order ID", "count"),
        Avg_Lead_Time=("Lead Time (raw days)", "mean"),
    ).reset_index()
    vol_med = by_state["Shipments"].median()
    lt_med = by_state["Avg_Lead_Time"].median()
    by_state["Bottleneck"] = (by_state["Shipments"] >= vol_med) & (by_state["Avg_Lead_Time"] >= lt_med)
    return by_state.sort_values(["Bottleneck", "Avg_Lead_Time"], ascending=[False, False])


def ship_mode_summary(df: pd.DataFrame) -> pd.DataFrame:
    out = df.groupby("Ship Mode").agg(
        Shipments=("Order ID", "count"),
        Avg_Lead_Time=("Lead Time (raw days)", "mean"),
        Median_Lead_Time=("Lead Time (raw days)", "median"),
        StdDev_Lead_Time=("Lead Time (raw days)", "std"),
        Avg_Sales=("Sales", "mean"),
        Avg_Profit_Margin=("Profit Margin", "mean"),
    ).reset_index()
    return out.sort_values("Avg_Lead_Time")


if __name__ == "__main__":
    df = full_pipeline()
    df.to_csv(os.path.join(DATA_DIR, "processed_orders.csv"), index=False)

    state_routes = route_summary(df, "State")
    region_routes = route_summary(df, "Region")
    state_routes.to_csv(os.path.join(DATA_DIR, "route_summary_state.csv"), index=False)
    region_routes.to_csv(os.path.join(DATA_DIR, "route_summary_region.csv"), index=False)

    print(f"Processed rows: {len(df)}")
    print(f"Rows dropped (bad dates): {df.attrs.get('rows_dropped_bad_dates')}")
    print(f"Rows dropped (negative lead time): {df.attrs.get('rows_dropped_negative_leadtime')}")
    print("\nTop 5 fastest state routes:")
    print(state_routes.head(5)[["Route (State)", "Shipments", "Avg_Lead_Time", "Efficiency_Score"]])
    print("\nBottom 5 slowest state routes:")
    print(state_routes.tail(5)[["Route (State)", "Shipments", "Avg_Lead_Time", "Efficiency_Score"]])
