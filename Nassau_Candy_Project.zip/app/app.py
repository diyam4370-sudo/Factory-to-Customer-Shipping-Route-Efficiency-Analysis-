"""
Nassau Candy Distributor — Shipping Route Efficiency Dashboard
Run with:  streamlit run app.py
"""

import pandas as pd
import plotly.express as px
import streamlit as st

from data_pipeline import (
    full_pipeline,
    route_summary,
    delay_frequency,
    bottleneck_states,
    ship_mode_summary,
)

st.set_page_config(
    page_title="Nassau Candy — Route Efficiency Dashboard",
    layout="wide",
    initial_sidebar_state="expanded",
)


# ---------------------------------------------------------------------------
# Data loading (cached)
# ---------------------------------------------------------------------------
@st.cache_data
def load_data():
    return full_pipeline()


df_raw = load_data()

# US state name -> USPS code, needed for the Plotly choropleth
US_STATE_ABBREV = {
    "Alabama": "AL", "Alaska": "AK", "Arizona": "AZ", "Arkansas": "AR", "California": "CA",
    "Colorado": "CO", "Connecticut": "CT", "Delaware": "DE", "District of Columbia": "DC",
    "Florida": "FL", "Georgia": "GA", "Hawaii": "HI", "Idaho": "ID", "Illinois": "IL",
    "Indiana": "IN", "Iowa": "IA", "Kansas": "KS", "Kentucky": "KY", "Louisiana": "LA",
    "Maine": "ME", "Maryland": "MD", "Massachusetts": "MA", "Michigan": "MI", "Minnesota": "MN",
    "Mississippi": "MS", "Missouri": "MO", "Montana": "MT", "Nebraska": "NE", "Nevada": "NV",
    "New Hampshire": "NH", "New Jersey": "NJ", "New Mexico": "NM", "New York": "NY",
    "North Carolina": "NC", "North Dakota": "ND", "Ohio": "OH", "Oklahoma": "OK", "Oregon": "OR",
    "Pennsylvania": "PA", "Rhode Island": "RI", "South Carolina": "SC", "South Dakota": "SD",
    "Tennessee": "TN", "Texas": "TX", "Utah": "UT", "Vermont": "VT", "Virginia": "VA",
    "Washington": "WA", "West Virginia": "WV", "Wisconsin": "WI", "Wyoming": "WY",
}

# ---------------------------------------------------------------------------
# Sidebar — global filters
# ---------------------------------------------------------------------------
st.sidebar.title("Filters")

min_date, max_date = df_raw["Order Date"].min(), df_raw["Order Date"].max()
date_range = st.sidebar.date_input(
    "Order date range", value=(min_date, max_date), min_value=min_date, max_value=max_date
)

regions = sorted(df_raw["Region"].unique())
sel_regions = st.sidebar.multiselect("Region", regions, default=regions)

states = sorted(df_raw["State/Province"].unique())
sel_states = st.sidebar.multiselect("State / Province", states, default=[])

ship_modes = sorted(df_raw["Ship Mode"].unique())
sel_modes = st.sidebar.multiselect("Ship Mode", ship_modes, default=ship_modes)

divisions = sorted(df_raw["Division"].unique())
sel_divisions = st.sidebar.multiselect("Division", divisions, default=divisions)

lt_min, lt_max = int(df_raw["Lead Time (raw days)"].min()), int(df_raw["Lead Time (raw days)"].max())
default_threshold = int(df_raw["Lead Time (raw days)"].quantile(0.75))
threshold = st.sidebar.slider(
    "Delay threshold (lead-time days)", min_value=lt_min, max_value=lt_max, value=default_threshold
)

st.sidebar.caption(
    "⚠️ Note: raw Ship Date values in the source data are not realistically "
    "aligned to Order Date (see project guide, §3). Lead-time figures here "
    "should be read as a RELATIVE efficiency ranking across routes, not as "
    "literal calendar-day delivery times."
)

# Apply filters
mask = (
    (df_raw["Order Date"] >= pd.to_datetime(date_range[0]))
    & (df_raw["Order Date"] <= pd.to_datetime(date_range[1]))
    & (df_raw["Region"].isin(sel_regions))
    & (df_raw["Ship Mode"].isin(sel_modes))
    & (df_raw["Division"].isin(sel_divisions))
)
if sel_states:
    mask &= df_raw["State/Province"].isin(sel_states)

df = df_raw[mask].copy()

if df.empty:
    st.warning("No data matches the selected filters. Adjust filters in the sidebar.")
    st.stop()

# ---------------------------------------------------------------------------
# Header + top-line KPIs
# ---------------------------------------------------------------------------
st.title("🍬 Nassau Candy Distributor — Shipping Route Efficiency Dashboard")

k1, k2, k3, k4 = st.columns(4)
k1.metric("Total Shipments", f"{len(df):,}")
k2.metric("Avg Lead Time (days)", f"{df['Lead Time (raw days)'].mean():,.1f}")
k3.metric("Active Routes (state-level)", f"{df['Route (State)'].nunique():,}")
delayed_pct = 100 * (df["Lead Time (raw days)"] > threshold).mean()
k4.metric(f"Delay Frequency (> {threshold}d)", f"{delayed_pct:.1f}%")

tab1, tab2, tab3, tab4 = st.tabs(
    ["📊 Route Efficiency Overview", "🗺️ Geographic Map", "🚚 Ship Mode Comparison", "🔍 Route Drill-Down"]
)

# ---------------------------------------------------------------------------
# TAB 1 — Route Efficiency Overview
# ---------------------------------------------------------------------------
with tab1:
    st.subheader("Route Performance Leaderboard")
    level = st.radio("Aggregate by:", ["State", "Region"], horizontal=True, key="overview_level")
    routes = route_summary(df, level)

    st.dataframe(
        routes.rename(columns={f"Route ({level})": "Route"})[
            ["Route", "Shipments", "Avg_Lead_Time", "Lead_Time_StdDev", "Efficiency_Score", "Total_Sales"]
        ].round(2),
        use_container_width=True,
        height=350,
    )

    c1, c2 = st.columns(2)
    with c1:
        top10 = routes.head(10)
        fig = px.bar(
            top10, x="Avg_Lead_Time", y=f"Route ({level})", orientation="h",
            title="Top 10 Most Efficient Routes (lowest avg lead time)",
            color="Avg_Lead_Time", color_continuous_scale="Greens_r",
        )
        fig.update_layout(yaxis=dict(autorange="reversed"))
        st.plotly_chart(fig, use_container_width=True)
    with c2:
        bottom10 = routes.tail(10).sort_values("Avg_Lead_Time")
        fig = px.bar(
            bottom10, x="Avg_Lead_Time", y=f"Route ({level})", orientation="h",
            title="Bottom 10 Least Efficient Routes (highest avg lead time)",
            color="Avg_Lead_Time", color_continuous_scale="Reds",
        )
        st.plotly_chart(fig, use_container_width=True)

# ---------------------------------------------------------------------------
# TAB 2 — Geographic Map
# ---------------------------------------------------------------------------
with tab2:
    st.subheader("US Shipping Efficiency Heatmap")
    by_state = df.groupby("State/Province").agg(
        Shipments=("Order ID", "count"),
        Avg_Lead_Time=("Lead Time (raw days)", "mean"),
    ).reset_index()
    by_state["State Code"] = by_state["State/Province"].map(US_STATE_ABBREV)
    map_df = by_state.dropna(subset=["State Code"])

    if map_df.empty:
        st.info("No US states in the current filter selection to map.")
    else:
        fig = px.choropleth(
            map_df, locations="State Code", locationmode="USA-states", color="Avg_Lead_Time",
            scope="usa", color_continuous_scale="RdYlGn_r",
            hover_name="State/Province", hover_data={"Shipments": True, "State Code": False},
            title="Average Lead Time by State (darker red = slower)",
        )
        st.plotly_chart(fig, use_container_width=True)

    st.subheader("Factory Locations")
    factories = df[["Factory", "Latitude", "Longitude"]].drop_duplicates().dropna()
    if not factories.empty:
        fig2 = px.scatter_geo(
            factories, lat="Latitude", lon="Longitude", text="Factory",
            scope="usa", title="Factory Locations",
        )
        fig2.update_traces(marker=dict(size=14, color="darkorange"))
        st.plotly_chart(fig2, use_container_width=True)

    st.subheader("Bottleneck States (high volume + high lead time)")
    bn = bottleneck_states(df)
    st.dataframe(
        bn[bn["Bottleneck"]][["State/Province", "Shipments", "Avg_Lead_Time"]].round(2),
        use_container_width=True,
    )

# ---------------------------------------------------------------------------
# TAB 3 — Ship Mode Comparison
# ---------------------------------------------------------------------------
with tab3:
    st.subheader("Lead Time by Ship Mode")
    sm = ship_mode_summary(df)
    st.dataframe(sm.round(3), use_container_width=True)

    c1, c2 = st.columns(2)
    with c1:
        fig = px.box(
            df, x="Ship Mode", y="Lead Time (raw days)", color="Ship Mode",
            title="Lead Time Distribution by Ship Mode",
        )
        st.plotly_chart(fig, use_container_width=True)
    with c2:
        fig = px.bar(
            sm, x="Ship Mode", y="Avg_Profit_Margin", color="Ship Mode",
            title="Avg Profit Margin by Ship Mode (descriptive cost-time tradeoff)",
        )
        st.plotly_chart(fig, use_container_width=True)

# ---------------------------------------------------------------------------
# TAB 4 — Route Drill-Down
# ---------------------------------------------------------------------------
with tab4:
    st.subheader("Drill Down by State / Region")
    d1, d2 = st.columns(2)
    with d1:
        drill_state = st.selectbox("Select a State/Province", ["(All)"] + states)
    with d2:
        drill_factory = st.selectbox("Select a Factory", ["(All)"] + sorted(df["Factory"].dropna().unique()))

    drill_df = df.copy()
    if drill_state != "(All)":
        drill_df = drill_df[drill_df["State/Province"] == drill_state]
    if drill_factory != "(All)":
        drill_df = drill_df[drill_df["Factory"] == drill_factory]

    if drill_df.empty:
        st.info("No shipments match this selection.")
    else:
        c1, c2, c3 = st.columns(3)
        c1.metric("Shipments", f"{len(drill_df):,}")
        c2.metric("Avg Lead Time", f"{drill_df['Lead Time (raw days)'].mean():,.1f} d")
        c3.metric("Total Sales", f"${drill_df['Sales'].sum():,.2f}")

        st.markdown("**Order-level timeline**")
        st.dataframe(
            drill_df[[
                "Order ID", "Order Date", "Ship Date", "Lead Time (raw days)",
                "Factory", "State/Province", "Ship Mode", "Product Name", "Sales",
            ]].sort_values("Order Date").round(2),
            use_container_width=True,
            height=400,
        )

        dff = px.scatter(
            drill_df, x="Order Date", y="Lead Time (raw days)", color="Ship Mode",
            title="Lead Time Over Time for this Selection",
        )
        st.plotly_chart(dff, use_container_width=True)
