# Nassau Candy Distributor — Shipping Route Efficiency Project

## Folder structure
```
nassau_project/
├── data/
│   ├── Nassau_Candy_Distributor.csv   # raw order data (as provided)
│   ├── factory_coordinates.csv        # factory lat/long lookup
│   └── product_factory_map.csv        # product -> factory lookup
├── app/
│   ├── data_pipeline.py               # cleaning, joins, feature engineering, KPIs
│   ├── app.py                         # Streamlit dashboard (4 pages)
│   └── requirements.txt
└── README.md
```

## Setup
```bash
cd nassau_project/app
pip install -r requirements.txt
```

## Run the dashboard
```bash
streamlit run app.py
```
This opens the dashboard in your browser (default: http://localhost:8501).

## Regenerate processed data files only (no UI)
```bash
python data_pipeline.py
```
This writes `processed_orders.csv`, `route_summary_state.csv`, and
`route_summary_region.csv` into `/data`.

## Important data note
The raw `Ship Date` column is not realistically related to `Order Date`
in the source file (orders are dated 2024–2025; ship dates are dated
2026–2030). The pipeline does **not** silently fix or hide this — it
computes lead time as given and the dashboard displays a warning banner
explaining that lead-time figures should be read as a **relative
efficiency ranking across routes**, not literal calendar-day delivery
times. See the Research Paper's Data Limitations section for full detail.
